const isAdmin = false;
document.addEventListener("DOMContentLoaded", () => {
    const fileList = document.getElementById("fileList");
    const uploadForm = document.getElementById("uploadForm");
    const fileInput = document.getElementById("fileInput");

    const API_URL = "https://www.morozovakarina.ru";

    async function fetchFiles() {
        const response = await fetch(`${API_URL}/files/`);
        const files = await response.json();
        fileList.innerHTML = "";
        files.forEach(file => {
            const li = document.createElement("li");
            li.textContent = `${file.filename} (${new Date(file.uploaded_at).toLocaleString()}) `;

            const downloadBtn = document.createElement("button");
            downloadBtn.textContent = "Скачать";
            downloadBtn.onclick = () => {
                window.location.href = `${API_URL}/download/${file.id}`;
            };

            const deleteBtn = document.createElement("button");
            deleteBtn.textContent = "Удалить";
            deleteBtn.onclick = async () => {
                await fetch(`${API_URL}/delete/${file.id}`, { method: "DELETE" });
                fetchFiles();
            };

            li.appendChild(downloadBtn);
            li.appendChild(deleteBtn);
            fileList.appendChild(li);
        });
    }

    uploadForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const file = fileInput.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append("file", file);

        await fetch(`${API_URL}/upload/`, {
            method: "POST",
            body: formData
        });

        fileInput.value = "";
        fetchFiles();
    });

    fetchFiles();
});