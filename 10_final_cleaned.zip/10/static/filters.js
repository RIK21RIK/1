/**
 * Данные для системы фильтрации документов
 */

// Структура данных по издающим органам
const issuersData = {
    // Президент РФ и его акты
    president: {
        name: 'Президент РФ',
        children: {
            'presidential-decree': 'Указ Президента РФ',
            'presidential-order': 'Распоряжение Президента РФ',
            'presidential-instruction': 'Поручение Президента РФ',
            'presidential-message': 'Послание Президента РФ Федеральному собранию'
        }
    },
    
    // Правительство РФ и его акты
    government: {
        name: 'Правительство РФ',
        children: {
            'government-decree': 'Постановление Правительства РФ',
            'government-order': 'Распоряжение Правительства РФ',
            'government-instruction': 'Поручение Правительства РФ',
            'government-concept': 'Концепция Правительства РФ',
            'government-strategy': 'Стратегия Правительства РФ'
        }
    },
    
    // Федеральные органы под Президентом РФ
    'presidential-ministries': {
        name: 'Федеральные органы (под Президентом РФ)',
        children: {
            'mvd': {
                name: 'МВД России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'mchs': {
                name: 'МЧС России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'mid': {
                name: 'МИД России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'rossotrudnichestvo': {
                name: 'Россотрудничество',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'minoborony': {
                name: 'Минобороны России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'fstek': {
                name: 'ФСТЭК России',
                docTypes: ['Приказ', 'Распоряжение', 'Методический документ', 'Руководящий документ', 'Методические рекомендации', 'Информационное сообщение']
            },
            'minjust': {
                name: 'Минюст России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'fsin': {
                name: 'ФСИН России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'fssp': {
                name: 'ФССП России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'gfs': {
                name: 'ГФС России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'svr': {
                name: 'СВР России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'fsb': {
                name: 'ФСБ России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации', 'Руководящий документ']
            },
            'rosgvardiya': {
                name: 'Росгвардия',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'fso': {
                name: 'ФСО России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'fsvts': {
                name: 'ФСВТС России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'rosfinmonitoring': {
                name: 'Росфинмониторинг',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Информационное письмо']
            },
            'rosarchive': {
                name: 'Росархив',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'gusp': {
                name: 'ГУСП',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'upravdelami': {
                name: 'Управление делами Президента Российской Федерации',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'fmba': {
                name: 'ФМБА России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            }
        }
    },
    
    // Федеральные органы под Правительством РФ
    'government-ministries': {
        name: 'Федеральные органы (под Правительством РФ)',
        children: {
            'minzdrav': {
                name: 'Минздрав России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации', 'Клинические рекомендации']
            },
            'roszdravnadzor': {
                name: 'Росздравнадзор',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Информационное письмо']
            },
            'minkultury': {
                name: 'Минкультуры России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'minobrnauki': {
                name: 'Минобрнауки России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'minprirody': {
                name: 'Минприроды России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'rosgidromet': {
                name: 'Росгидромет',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'rosprirodnadzor': {
                name: 'Росприроднадзор',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'rosvodresursy': {
                name: 'Росводресурсы',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'rosleshoz': {
                name: 'Рослесхоз',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'rosnedra': {
                name: 'Роснедра',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'minpromtorg': {
                name: 'Минпромторг России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'rosstandart': {
                name: 'Росстандарт',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'ГОСТ', 'ГОСТ Р']
            },
            'minprosveshcheniya': {
                name: 'Министерство просвещения Российской Федерации',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'minvostokrazvitiya': {
                name: 'Минвостокразвития России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'minselhoz': {
                name: 'Минсельхоз России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'rosselkhoznadzor': {
                name: 'Россельхознадзор',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'rosrybolovstvo': {
                name: 'Росрыболовство',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'minsport': {
                name: 'Минспорт России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'minstroy': {
                name: 'Минстрой России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации', 'СП', 'СНиП']
            },
            'mintrans': {
                name: 'Минтранс России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'rostransnadzor': {
                name: 'Ространснадзор',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'rosaviaciya': {
                name: 'Росавиация',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'rosavtodor': {
                name: 'Росавтодор',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'roszheldor': {
                name: 'Росжелдор',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'rosmorrechflot': {
                name: 'Росморречфлот',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'mintrud': {
                name: 'Минтруд России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'rostrud': {
                name: 'Роструд',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'minfin': {
                name: 'Минфин России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации', 'Письмо']
            },
            'fns': {
                name: 'ФНС России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Письмо', 'Информация']
            },
            'federalnaya-probirnaya-palata': {
                name: 'Федеральная пробирная палата',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'rosalkogoltabakkontrol': {
                name: 'Росалкогольтабакконтроль',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'fts': {
                name: 'ФТС России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Письмо']
            },
            'kaznacheystvo': {
                name: 'Казначейство России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Письмо']
            },
            'rosimushchestvo': {
                name: 'Росимущество',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'mintsifry': {
                name: 'Минцифры России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации', 'Методические документы']
            },
            'roskomnadzor': {
                name: 'Роскомнадзор',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации', 'Разъяснение']
            },
            'mineconom': {
                name: 'Минэкономразвития России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'rosakkreditaciya': {
                name: 'Росаккредитация',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'rosstat': {
                name: 'Федеральная служба государственной статистики',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'rospatent': {
                name: 'Роспатент',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'minenergo': {
                name: 'Минэнерго России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            }
        }
    },
    
    // Федеральные службы под Правительством РФ
    'government-services': {
        name: 'Федеральные службы (под Правительством РФ)',
        children: {
            'fas': {
                name: 'ФАС России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Разъяснение', 'Письмо']
            },
            'rosreestr': {
                name: 'Росреестр',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Письмо']
            },
            'rospotrebnadzor': {
                name: 'Роспотребнадзор',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации', 'Санитарные правила']
            },
            'rosobrnadzor': {
                name: 'Рособрнадзор',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'rostechnadzor': {
                name: 'Ростехнадзор',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Руководство по безопасности', 'Федеральные нормы и правила']
            },
            'rosrezerv': {
                name: 'Росрезерв',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'rosmolodezh': {
                name: 'Росмолодежь',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            },
            'fadn': {
                name: 'ФАДН России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание']
            }
        }
    },
    
    // Государственные органы
    'other-state-bodies': {
        name: 'Государственные органы',
        children: {
            'schetnaya-palata': {
                name: 'Счетная палата',
                docTypes: ['Постановление', 'Стандарт', 'Методические рекомендации', 'Отчет']
            },
            'sledcom': {
                name: 'СК России',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации']
            },
            'cbr': {
                name: 'Банк России',
                docTypes: ['Положение', 'Указание', 'Инструкция', 'Методические рекомендации', 'Письмо', 'Информационное письмо', 'Разъяснение', 'Стандарт']
            },
            'genprok': {
                name: 'Генеральная прокуратура Российской Федерации',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации', 'Информационное письмо']
            },
            'ras': {
                name: 'Российская академия наук',
                docTypes: ['Постановление', 'Распоряжение']
            }
        }
    },
    
    // Государственные корпорации
    'state-corporations': {
        name: 'Государственные корпорации',
        children: {
            'rosatom': {
                name: 'Госкорпорация Росатом',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации', 'Стандарт']
            },
            'roskosmos': {
                name: 'Госкорпорация "Роскосмос"',
                docTypes: ['Приказ', 'Распоряжение', 'Указание', 'Методические рекомендации', 'Стандарт']
            },
            'veb': {
                name: 'ВЭБ.РФ',
                docTypes: ['Приказ', 'Распоряжение', 'Положение', 'Стандарт']
            }
        }
    },
    
    // Государственные внебюджетные фонды
    'state-funds': {
        name: 'Государственные внебюджетные фонды',
        children: {
            'pfr': {
                name: 'ПФР',
                docTypes: ['Постановление', 'Распоряжение', 'Информация']
            },
            'foms': {
                name: 'ФОМС',
                docTypes: ['Приказ', 'Правила', 'Методические указания']
            },
            'fss': {
                name: 'Фонд социального страхования Российской Федерации',
                docTypes: ['Приказ', 'Постановление', 'Информация']
            },
            'sfr': {
                name: 'Фонд пенсионного и социального страхования Российской Федерации',
                docTypes: ['Приказ', 'Постановление', 'Информация']
            }
        }
    },
    
    // Федеральное собрание РФ
    'federal-assembly': {
        name: 'Федеральное собрание РФ',
        children: {
            'state-duma': {
                name: 'Государственная Дума',
                docTypes: ['Федеральный закон', 'Постановление', 'Обращение', 'Заявление']
            },
            'federation-council': {
                name: 'Совет Федерации',
                docTypes: ['Постановление', 'Обращение', 'Заявление']
            }
        }
    },
    
    // Суды
    'courts': {
        name: 'Судебная система',
        children: {
            'constitutional-court': {
                name: 'Конституционный Суд РФ',
                docTypes: ['Постановление', 'Определение', 'Решение']
            },
            'supreme-court': {
                name: 'Верховный Суд РФ',
                docTypes: ['Постановление Пленума', 'Постановление Президиума', 'Определение', 'Решение', 'Обзор судебной практики']
            },
            'arbitrazhny-courts': {
                name: 'Арбитражные суды',
                docTypes: ['Постановление', 'Определение', 'Решение']
            },
            'general-jurisdiction': {
                name: 'Суды общей юрисдикции',
                docTypes: ['Постановление', 'Определение', 'Решение']
            }
        }
    },
    
    // Упраздненные органы
    'abolished-authorities': {
        name: 'Упраздненные федеральные органы',
        children: {
            'rospechat': 'Роспечать',
            'rossvyaz': 'Россвязь',
            'rosturizm': 'Ростуризм',
            'spetsstroi': 'Спецстрой России',
            'fskn': 'ФСКН России',
            'minkavkaz': 'Минкавказ России',
            'minkrym': 'Министерство Российской Федерации по делам Крыма',
            'rosfinnadzor': 'Росфиннадзор',
            'minobrnauki-old': 'Минобрнауки (старое)',
            'fms': 'ФМС России',
            'fst': 'ФСТ России',
            'fano': 'ФАНО России',
            'rosgranica': 'Росграница',
            'old-roskosmos': 'Роскосмос (старый)'
        }
    },

    // Международные организации
    'international-organizations': {
        name: 'Международные организации',
        children: {
            'un': {
                name: 'Организация Объединенных Наций (ООН)',
                docTypes: ['Конвенция', 'Резолюция', 'Декларация', 'Рекомендации']
            },
            'cis': {
                name: 'Содружество Независимых Государств (СНГ)',
                docTypes: ['Соглашение', 'Договор', 'Решение', 'Декларация']
            },
            'eaeu': {
                name: 'Евразийский экономический союз (ЕАЭС)',
                docTypes: ['Решение', 'Распоряжение', 'Рекомендация', 'Технический регламент']
            },
            'iso': {
                name: 'Международная организация по стандартизации (ИСО)',
                docTypes: ['Стандарт', 'Руководство', 'Спецификация']
            },
            'iec': {
                name: 'Международная электротехническая комиссия (МЭК)',
                docTypes: ['Стандарт', 'Руководство', 'Спецификация']
            }
        }
    }
};

// Объекты защиты
const protectionObjects = {
    'kii': 'КИИ',
    'pdn': 'ПДн',
    'asu-tp': 'АСУ ТП',
    'gis-mis': 'ГИС и МИС',
    'it-infra': 'ИТ-инфраструктура',
    'intellectual-property': 'Интеллектуальная собственность',
    'iot': 'IoT',
    'fin-services': 'Финансовые услуги',
    'cloud': 'Облачные сервисы',
    'state-secrets': 'Государственная тайна',
    'trade-secrets': 'Коммерческая тайна'
};

// Типы нормативно-правовых актов
const actTypes = {
    'Конституция РФ': 'Конституция РФ',
    'Международные акты': 'Международные договоры и акты',
    'Федеральный конституционный закон': 'Федеральный конституционный закон (ФКЗ)',
    'Федеральный закон': 'Федеральный закон (ФЗ)',
    'Указ Президента РФ': 'Указ Президента РФ',
    'Распоряжение Президента РФ': 'Распоряжение Президента РФ',
    'Постановление Правительства РФ': 'Постановление Правительства РФ',
    'Распоряжение Правительства РФ': 'Распоряжение Правительства РФ',
    'Приказ министерства': 'Приказ федерального органа исполнительной власти (министерства, службы, агентства)',
    'Приказ государственной службы': 'Приказ государственной службы',
    'Технический регламент': 'Технический регламент',
    'Стандарт': 'Стандарт (ГОСТ Р, ОСТ, СТО, рекомендации в области стандартизации)',
    'Методический документ': 'Методический документ (рекомендации, указания, обзоры)',
    'Руководящий документ': 'Руководящий документ (РД)',
    'Судебное решение': 'Судебные акты (решения, постановления, определения судов)'
};

// Стадии жизненного цикла
const lifecycle = {
    'draft': 'Проект',
    'review': 'На рассмотрении',
    'approved': 'Утверждённый',
    'active': 'Действующий',
    'modified': 'Изменённый',
    'suspended': 'Приостановленный',
    'canceled': 'Отменённый',
    'revision': 'На пересмотре',
    'expired': 'Срок действия истек'
};

/**
 * Генерация HTML для фильтров
 */
function initializeFilters() {
    const container = document.getElementById('filters-container');
    if (!container) return;
    
    // Создаем фильтр по издающим органам
    container.appendChild(createIssuerFilter());
    
    // Создаем фильтр по объектам защиты
    container.appendChild(createProtectionFilter());
    
    // Создаем фильтр по датам
    container.appendChild(createDateFilter());
    
    // Создаем фильтр по типам актов
    container.appendChild(createActTypeFilter());
    
    // Создаем фильтр по стадиям жизненного цикла
    container.appendChild(createLifecycleFilter());
    
    // Добавляем обработчики событий для всех фильтров
    setupFilterEvents();
}

/**
 * Создает фильтр по издающим органам
 */
function createIssuerFilter() {
    const group = document.createElement('div');
    group.className = 'filter-group mb-4';
    
    // Заголовок группы фильтров
    const header = document.createElement('div');
    header.className = 'flex justify-between items-center cursor-pointer mb-2';
    header.setAttribute('data-toggle', 'issuer');
    header.innerHTML = `
        <h4 class="font-medium">Издающий орган</h4>
        <i class="fas fa-chevron-down text-gray-500 transition-transform"></i>
    `;
    
    // Содержимое группы фильтров
    const content = document.createElement('div');
    content.className = 'filter-content hidden';
    content.id = 'filter-issuer';
    
    // Добавляем каждую категорию органов
    for (const [key, value] of Object.entries(issuersData)) {
        const categoryItem = document.createElement('div');
        categoryItem.className = 'ml-2 mb-2';
        
        // Если у категории есть дочерние элементы
        if (value.children && Object.keys(value.children).length > 0) {
            // Создаем раскрывающийся заголовок категории
            const categoryHeader = document.createElement('div');
            categoryHeader.className = 'flex items-center justify-between cursor-pointer';
            categoryHeader.setAttribute('data-toggle', key);
            categoryHeader.innerHTML = `
                <label class="flex items-center cursor-pointer">
                    <input type="checkbox" name="issuer" value="${key}" class="mr-2 filter-parent">
                    <span>${value.name}</span>
                </label>
                <i class="fas fa-chevron-right text-gray-500 transition-transform"></i>
            `;
            
            // Создаем контейнер для дочерних элементов
            const childrenContainer = document.createElement('div');
            childrenContainer.className = 'ml-6 hidden';
            childrenContainer.id = `filter-${key}`;
            
            // Добавляем дочерние элементы
            for (const [childKey, childValue] of Object.entries(value.children)) {
                const childItem = document.createElement('div');
                childItem.className = 'my-1';
                
                // Если дочерний элемент имеет расширенную структуру с типами документов
                if (typeof childValue === 'object' && childValue.name) {
                    childItem.innerHTML = `
                        <label class="flex items-center">
                            <input type="checkbox" name="issuer-sub" value="${childKey}" 
                                   data-parent="${key}" class="mr-2 filter-child">
                            <span>${childValue.name}</span>
                        </label>
                    `;
                    
                    // Если есть типы документов, добавляем их как дополнительную информацию
                    if (childValue.docTypes && childValue.docTypes.length > 0) {
                        const docTypesInfo = document.createElement('div');
                        docTypesInfo.className = 'ml-5 mt-1 text-xs text-gray-500 hidden';
                        docTypesInfo.id = `doctypes-${childKey}`;
                        
                        // Создаем список типов документов
                        const docTypesList = document.createElement('div');
                        docTypesList.className = 'flex flex-wrap gap-1';
                        childValue.docTypes.forEach(docType => {
                            const docTypeTag = document.createElement('span');
                            docTypeTag.className = 'bg-gray-100 px-1.5 py-0.5 rounded text-xs';
                            docTypeTag.textContent = docType;
                            docTypesList.appendChild(docTypeTag);
                        });
                        
                        docTypesInfo.appendChild(docTypesList);
                        
                        // Добавляем иконку "i" для отображения типов документов
                        const infoIcon = document.createElement('i');
                        infoIcon.className = 'fas fa-info-circle text-gray-400 ml-1 cursor-help';
                        infoIcon.setAttribute('data-doc-types', childKey);
                        infoIcon.title = 'Показать типы документов';
                        
                        // Добавляем иконку после checkbox
                        const labelSpan = childItem.querySelector('span');
                        labelSpan.insertAdjacentElement('afterend', infoIcon);
                        
                        // Добавляем информацию о типах документов после основного элемента
                        childItem.appendChild(docTypesInfo);
                    }
                } else {
                    // Простой вариант, если нет расширенной структуры
                    childItem.innerHTML = `
                        <label class="flex items-center">
                            <input type="checkbox" name="issuer-sub" value="${childKey}" 
                                   data-parent="${key}" class="mr-2 filter-child">
                            <span>${childValue}</span>
                        </label>
                    `;
                }
                
                childrenContainer.appendChild(childItem);
            }
            
            // Если дочерних элементов много, добавляем ссылку "Показать все..."
            if (Object.keys(value.children).length > 5) {
                const showAllLink = document.createElement('div');
                showAllLink.className = 'my-1 text-xs text-blue-600 cursor-pointer';
                showAllLink.textContent = 'Показать все органы...';
                showAllLink.setAttribute('data-show-all', key);
                childrenContainer.appendChild(showAllLink);
            }
            
            categoryItem.appendChild(categoryHeader);
            categoryItem.appendChild(childrenContainer);
        } else {
            // Создаем простой чекбокс для категории без дочерних элементов
            categoryItem.innerHTML = `
                <label class="flex items-center cursor-pointer">
                    <input type="checkbox" name="issuer" value="${key}" class="mr-2">
                    <span>${value.name}</span>
                </label>
            `;
        }
        
        content.appendChild(categoryItem);
    }
    
    group.appendChild(header);
    group.appendChild(content);
    return group;
}

/**
 * Создает фильтр по объектам защиты
 */
function createProtectionFilter() {
    const group = document.createElement('div');
    group.className = 'filter-group mb-4';
    
    // Заголовок группы фильтров
    const header = document.createElement('div');
    header.className = 'flex justify-between items-center cursor-pointer mb-2';
    header.setAttribute('data-toggle', 'protection');
    header.innerHTML = `
        <h4 class="font-medium">Объекты защиты</h4>
        <i class="fas fa-chevron-down text-gray-500 transition-transform"></i>
    `;
    
    // Содержимое группы фильтров
    const content = document.createElement('div');
    content.className = 'filter-content hidden';
    content.id = 'filter-protection';
    
    // Добавляем каждый объект защиты
    for (const [key, name] of Object.entries(protectionObjects)) {
        const item = document.createElement('div');
        item.className = 'ml-2';
        item.innerHTML = `
            <label class="flex items-center">
                <input type="checkbox" name="protection" value="${key}" class="mr-2">
                <span>${name}</span>
            </label>
        `;
        content.appendChild(item);
    }
    
    group.appendChild(header);
    group.appendChild(content);
    return group;
}

/**
 * Создает фильтр по датам
 */
function createDateFilter() {
    const group = document.createElement('div');
    group.className = 'filter-group mb-4';
    
    // Заголовок группы фильтров
    const header = document.createElement('div');
    header.className = 'flex justify-between items-center cursor-pointer mb-2';
    header.setAttribute('data-toggle', 'dates');
    header.innerHTML = `
        <h4 class="font-medium">Даты</h4>
        <i class="fas fa-chevron-down text-gray-500 transition-transform"></i>
    `;
    
    // Содержимое группы фильтров
    const content = document.createElement('div');
    content.className = 'filter-content hidden';
    content.id = 'filter-dates';
    
    // Диапазон дат принятия
    const adoptionDateGroup = document.createElement('div');
    adoptionDateGroup.className = 'ml-2 mb-2';
    adoptionDateGroup.innerHTML = `
        <label class="block text-sm mb-1">Дата принятия</label>
        <div class="flex gap-2">
            <input type="date" id="adoption-date-from" class="w-1/2 rounded-md border border-gray-300 shadow-sm p-1 text-sm">
            <input type="date" id="adoption-date-to" class="w-1/2 rounded-md border border-gray-300 shadow-sm p-1 text-sm">
        </div>
    `;
    
    // Диапазон дат вступления в силу
    const effectDateGroup = document.createElement('div');
    effectDateGroup.className = 'ml-2 mb-2';
    effectDateGroup.innerHTML = `
        <label class="block text-sm mb-1">Дата вступления в силу</label>
        <div class="flex gap-2">
            <input type="date" id="effect-date-from" class="w-1/2 rounded-md border border-gray-300 shadow-sm p-1 text-sm">
            <input type="date" id="effect-date-to" class="w-1/2 rounded-md border border-gray-300 shadow-sm p-1 text-sm">
        </div>
    `;
    
    // Диапазон дат обновления
    const updateDateGroup = document.createElement('div');
    updateDateGroup.className = 'ml-2';
    updateDateGroup.innerHTML = `
        <label class="block text-sm mb-1">Дата последнего обновления</label>
        <div class="flex gap-2">
            <input type="date" id="update-date-from" class="w-1/2 rounded-md border border-gray-300 shadow-sm p-1 text-sm">
            <input type="date" id="update-date-to" class="w-1/2 rounded-md border border-gray-300 shadow-sm p-1 text-sm">
        </div>
    `;
    
    content.appendChild(adoptionDateGroup);
    content.appendChild(effectDateGroup);
    content.appendChild(updateDateGroup);
    
    group.appendChild(header);
    group.appendChild(content);
    return group;
}

/**
 * Создает фильтр по типам актов
 */
function createActTypeFilter() {
    const group = document.createElement('div');
    group.className = 'filter-group mb-4';
    
    // Заголовок группы фильтров
    const header = document.createElement('div');
    header.className = 'flex justify-between items-center cursor-pointer mb-2';
    header.setAttribute('data-toggle', 'act-types');
    header.innerHTML = `
        <h4 class="font-medium">Тип акта</h4>
        <i class="fas fa-chevron-down text-gray-500 transition-transform"></i>
    `;
    
    // Содержимое группы фильтров
    const content = document.createElement('div');
    content.className = 'filter-content hidden';
    content.id = 'filter-act-types';
    
    // Добавляем каждый тип акта
    for (const [key, name] of Object.entries(actTypes)) {
        const item = document.createElement('div');
        item.className = 'ml-2';
        item.innerHTML = `
            <label class="flex items-center">
                <input type="checkbox" name="act-type" value="${key}" class="mr-2">
                <span>${name}</span>
            </label>
        `;
        content.appendChild(item);
    }
    
    group.appendChild(header);
    group.appendChild(content);
    return group;
}

/**
 * Создает фильтр по стадиям жизненного цикла
 */
function createLifecycleFilter() {
    const group = document.createElement('div');
    group.className = 'filter-group mb-4';
    
    // Заголовок группы фильтров
    const header = document.createElement('div');
    header.className = 'flex justify-between items-center cursor-pointer mb-2';
    header.setAttribute('data-toggle', 'lifecycle');
    header.innerHTML = `
        <h4 class="font-medium">Стадия жизненного цикла</h4>
        <i class="fas fa-chevron-down text-gray-500 transition-transform"></i>
    `;
    
    // Содержимое группы фильтров
    const content = document.createElement('div');
    content.className = 'filter-content hidden';
    content.id = 'filter-lifecycle';
    
    // Добавляем каждую стадию жизненного цикла
    for (const [key, name] of Object.entries(lifecycle)) {
        const item = document.createElement('div');
        item.className = 'ml-2';
        item.innerHTML = `
            <label class="flex items-center">
                <input type="checkbox" name="lifecycle" value="${key}" class="mr-2">
                <span>${name}</span>
            </label>
        `;
        content.appendChild(item);
    }
    
    group.appendChild(header);
    group.appendChild(content);
    return group;
}

/**
 * Настраивает обработчики событий для фильтров
 */
function setupFilterEvents() {
    // Обработчики для заголовков групп фильтров
    document.querySelectorAll('[data-toggle]').forEach(toggle => {
        toggle.addEventListener('click', function() {
            const targetId = this.getAttribute('data-toggle');
            const target = document.getElementById(`filter-${targetId}`) || this.nextElementSibling;
            const icon = this.querySelector('i');
            
            if (target) {
                target.classList.toggle('hidden');
                if (icon) {
                    if (icon.classList.contains('fa-chevron-right')) {
                        icon.classList.replace('fa-chevron-right', 'fa-chevron-down');
                    } else if (icon.classList.contains('fa-chevron-down')) {
                        if (!target.classList.contains('hidden')) {
                            icon.classList.replace('fa-chevron-down', 'fa-chevron-up');
                        } else {
                            icon.classList.replace('fa-chevron-up', 'fa-chevron-down');
                        }
                    }
                }
            }
        });
    });
    
    // Обработчики для иконок информации о типах документов
    document.querySelectorAll('[data-doc-types]').forEach(infoIcon => {
        infoIcon.addEventListener('click', function(e) {
            e.stopPropagation(); // Предотвращаем всплытие события
            
            const docTypesId = this.getAttribute('data-doc-types');
            const docTypesContainer = document.getElementById(`doctypes-${docTypesId}`);
            
            if (docTypesContainer) {
                docTypesContainer.classList.toggle('hidden');
            }
        });
    });
    
    // Обработчики для родительских чекбоксов
    document.querySelectorAll('.filter-parent').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const parent = this.value;
            const childElements = document.querySelectorAll(`.filter-child[data-parent="${parent}"]`);
            
            childElements.forEach(child => {
                child.checked = this.checked;
            });
        });
    });
    
    // Обработчики для дочерних чекбоксов
    document.querySelectorAll('.filter-child').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const parent = this.getAttribute('data-parent');
            const parentCheckbox = document.querySelector(`.filter-parent[value="${parent}"]`);
            const siblings = document.querySelectorAll(`.filter-child[data-parent="${parent}"]`);
            
            if (parentCheckbox) {
                // Если хотя бы один дочерний элемент выбран, родитель тоже должен быть выбран
                const anyChecked = Array.from(siblings).some(child => child.checked);
                parentCheckbox.checked = anyChecked;
            }
        });
    });
    
    // Обработчики для ссылок "Показать все..."
    document.querySelectorAll('[data-show-all]').forEach(link => {
        link.addEventListener('click', function() {
            const container = this.parentElement;
            const items = container.querySelectorAll('.my-1:not(:nth-child(-n+5))');
            
            items.forEach(item => {
                item.classList.toggle('hidden');
            });
            
            if (this.textContent.includes('Показать все')) {
                this.textContent = 'Скрыть';
            } else {
                this.textContent = 'Показать все органы...';
            }
        });
    });
    
    // Кнопка применения фильтров
    const applyBtn = document.getElementById('apply-filters');
    if (applyBtn) {
        applyBtn.addEventListener('click', applyFilters);
    }
    
    // Кнопка сброса фильтров
    const resetBtn = document.getElementById('reset-filters');
    if (resetBtn) {
        resetBtn.addEventListener('click', resetFilters);
    }
    
    // Поиск по фильтрам
    const filterSearch = document.getElementById('filter-search');
    if (filterSearch) {
        filterSearch.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            filterSearchItems(searchTerm);
        });
    }
    
    // Мобильная кнопка фильтров
    const mobileFilterBtn = document.getElementById('mobile-filters-btn');
    if (mobileFilterBtn) {
        mobileFilterBtn.addEventListener('click', function() {
            const filtersPanel = document.querySelector('.w-full.lg\\:w-1\\/4');
            if (filtersPanel) {
                filtersPanel.classList.toggle('hidden');
                filtersPanel.classList.toggle('lg:block');
            }
        });
    }

    // Обработчики для кнопок с часто используемыми ключевыми словами
    const suggestedKeywordButtons = document.querySelectorAll('.suggested-keyword-btn');
    const keywordDocumentSearchInput = document.getElementById('keyword-document-search');

    if (suggestedKeywordButtons && keywordDocumentSearchInput) {
        suggestedKeywordButtons.forEach(button => {
            button.addEventListener('click', function() {
                const keyword = this.textContent;
                const currentSearchValue = keywordDocumentSearchInput.value.trim();
                if (currentSearchValue) {
                    keywordDocumentSearchInput.value = currentSearchValue + ' ' + keyword;
                } else {
                    keywordDocumentSearchInput.value = keyword;
                }
                keywordDocumentSearchInput.focus(); // Фокусируемся на поле ввода
            });
        });
    }
}

/**
 * Фильтрует элементы в фильтрах по поисковому запросу
 */
function filterSearchItems(searchTerm) {
    // Показываем все элементы, если поиск пустой
    if (!searchTerm) {
        document.querySelectorAll('.filter-group label').forEach(label => {
            label.parentElement.style.display = '';
        });
        return;
    }
    
    // Фильтруем элементы по поисковому запросу
    document.querySelectorAll('.filter-group label').forEach(label => {
        const text = label.textContent.toLowerCase();
        if (text.includes(searchTerm)) {
            label.parentElement.style.display = '';
            
            // Раскрываем родительские группы
            let parent = label.closest('.filter-content');
            while (parent) {
                parent.classList.remove('hidden');
                
                // Меняем иконку заголовка
                const header = parent.previousElementSibling;
                if (header && header.querySelector('i.fas')) {
                    const icon = header.querySelector('i.fas');
                    if (icon.classList.contains('fa-chevron-down')) {
                        icon.classList.replace('fa-chevron-down', 'fa-chevron-up');
                    }
                }
                
                parent = parent.parentElement.closest('.filter-content');
            }
        } else {
            label.parentElement.style.display = 'none';
        }
    });
}

/**
 * Применяет выбранные фильтры к списку документов
 */
function applyFilters() {
    // Собираем все выбранные значения фильтров
    const filters = {
        issuers: getSelectedValues('issuer'),
        issuersSub: getSelectedValues('issuer-sub'),
        protection: getSelectedValues('protection'),
        actTypes: getSelectedValues('act-type'),
        lifecycle: getSelectedValues('lifecycle'),
        keywords: document.getElementById('keyword-document-search')?.value.toLowerCase() || '',
        dates: {
            adoption: {
                from: document.getElementById('adoption-date-from')?.value || '',
                to: document.getElementById('adoption-date-to')?.value || ''
            },
            effect: {
                from: document.getElementById('effect-date-from')?.value || '',
                to: document.getElementById('effect-date-to')?.value || ''
            },
            update: {
                from: document.getElementById('update-date-from')?.value || '',
                to: document.getElementById('update-date-to')?.value || ''
            }
        }
    };
    
    // Сохраняем текущие фильтры
    currentFilters = filters;
    
    // Применяем фильтры к списку документов
    renderDocumentsList(document.getElementById('search-docs').value.toLowerCase());
    
    // На мобильных устройствах скрываем панель фильтров после применения
    if (window.innerWidth < 1024) {
        const filtersPanel = document.querySelector('.w-full.lg\\:w-1\\/4');
        if (filtersPanel) {
            filtersPanel.classList.add('hidden');
            filtersPanel.classList.add('lg:block');
        }
    }
    
    // Показываем уведомление о применении фильтров
    showNotification('Фильтры применены');
}

/**
 * Сбрасывает все фильтры
 */
function resetFilters() {
    // Сбрасываем чекбоксы
    document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
        checkbox.checked = false;
    });
    
    // Сбрасываем поля дат
    document.querySelectorAll('input[type="date"]').forEach(dateInput => {
        dateInput.value = '';
    });
    
    // Сбрасываем поиск по фильтрам
    const filterSearch = document.getElementById('filter-search');
    if (filterSearch) {
        filterSearch.value = '';
        filterSearchItems('');
    }
    
    // Сбрасываем поиск по ключевым словам в документах
    const keywordSearch = document.getElementById('keyword-document-search');
    if (keywordSearch) {
        keywordSearch.value = '';
    }
    
    // Сбрасываем текущие фильтры
    currentFilters = null;
    
    // Обновляем список документов
    renderDocumentsList(document.getElementById('search-docs').value.toLowerCase());
    
    // Показываем уведомление о сбросе фильтров
    showNotification('Фильтры сброшены');
}

/**
 * Возвращает массив выбранных значений для заданного имени фильтра
 */
function getSelectedValues(name) {
    const checkboxes = document.querySelectorAll(`input[name="${name}"]:checked`);
    return Array.from(checkboxes).map(checkbox => checkbox.value);
}

/**
 * Фильтрует документы согласно выбранным фильтрам
 */
function filterDocuments(docs, filters) {
    if (!filters) return docs;
    
    return docs.filter(doc => {
        // Проверка по ключевым словам
        if (filters.keywords) {
            const keywords = filters.keywords.split(' ').filter(kw => kw.length > 0);
            const titleMatch = keywords.every(kw => doc.title.toLowerCase().includes(kw));
            const contentMatch = doc.content && typeof doc.content === 'string' ? keywords.every(kw => doc.content.toLowerCase().includes(kw)) : false;
            if (!titleMatch && !contentMatch) {
                return false;
            }
        }

        // Проверяем соответствие издающему органу
        if (filters.issuers.length > 0 || filters.issuersSub.length > 0) {
            // Если заданы конкретные подразделения
            if (filters.issuersSub.length > 0) {
                if (!doc.issuer_sub || !filters.issuersSub.includes(doc.issuer_sub)) {
                    return false;
                }
            } 
            // Если заданы только группы органов и не заданы подразделения
            else if (filters.issuers.length > 0) {
                if (!doc.issuer || !filters.issuers.includes(doc.issuer)) {
                    return false;
                }
            }
        }
        
        // Проверяем соответствие объекту защиты
        if (filters.protection.length > 0) {
            if (!doc.protection || !doc.protection.some(p => filters.protection.includes(p))) {
                return false;
            }
        }
        
        // Проверяем соответствие типу акта
        if (filters.actTypes.length > 0) {
            if (!doc.act_type || !filters.actTypes.includes(doc.act_type)) {
                return false;
            }
        }
        
        // Проверяем соответствие стадии жизненного цикла
        if (filters.lifecycle.length > 0) {
            if (!doc.lifecycle || !filters.lifecycle.includes(doc.lifecycle)) {
                return false;
            }
        }
        
        // Проверяем соответствие датам
        // Дата принятия
        if (doc.date) {
            const docDate = new Date(doc.date);
            
            if (filters.dates.adoption.from && new Date(filters.dates.adoption.from) > docDate) {
                return false;
            }
            if (filters.dates.adoption.to && new Date(filters.dates.adoption.to) < docDate) {
                return false;
            }
        }
        
        // Дата вступления в силу
        if (doc.effect_date) {
            const effectDate = new Date(doc.effect_date);
            
            if (filters.dates.effect.from && new Date(filters.dates.effect.from) > effectDate) {
                return false;
            }
            if (filters.dates.effect.to && new Date(filters.dates.effect.to) < effectDate) {
                return false;
            }
        }
        
        // Дата обновления
        if (doc.update_date) {
            const updateDate = new Date(doc.update_date);
            
            if (filters.dates.update.from && new Date(filters.dates.update.from) > updateDate) {
                return false;
            }
            if (filters.dates.update.to && new Date(filters.dates.update.to) < updateDate) {
                return false;
            }
        }
        
        // Если документ прошел все проверки, возвращаем true
        return true;
    });
}

// Глобальная переменная для хранения текущих фильтров
let currentFilters = null;

// Инициализируем фильтры при загрузке страницы
document.addEventListener('DOMContentLoaded', initializeFilters); 