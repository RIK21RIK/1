// Класс управления аутентификацией
class AuthManager {
    constructor() {
        this.currentUser = null;
        this.isAuthenticated = false;
        this.authStateListeners = new Set();
        this.initializeFromStorage();
    }

    // Инициализация состояния аутентификации из localStorage
    initializeFromStorage() {
        const userData = localStorage.getItem('user');
        if (userData) {
            this.currentUser = JSON.parse(userData);
            this.isAuthenticated = true;
            this.notifyAuthStateChange();
        }
    }

    // Регистрация нового пользователя
    async register(userData) {
        try {
            // Валидация данных
            this.validateUserData(userData);
            
            // Хеширование пароля (в реальном приложении)
            const hashedPassword = await this.hashPassword(userData.password);
            
            // Создание пользователя
            const user = {
                id: crypto.randomUUID(),
                email: userData.email,
                name: userData.name,
                created: new Date().toISOString(),
                settings: {
                    theme: 'light',
                    notifications: true
                }
            };

            // Сохранение в localStorage (в реальном приложении - отправка на сервер)
            localStorage.setItem('user', JSON.stringify(user));
            
            this.currentUser = user;
            this.isAuthenticated = true;
            this.notifyAuthStateChange();
            
            return { success: true, user };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    // Вход пользователя
    async login(credentials) {
        try {
            // В реальном приложении - проверка на сервере
            const userData = localStorage.getItem('user');
            if (!userData) {
                throw new Error('Пользователь не найден');
            }

            const user = JSON.parse(userData);
            if (user.email !== credentials.email) {
                throw new Error('Неверный email или пароль');
            }

            this.currentUser = user;
            this.isAuthenticated = true;
            this.notifyAuthStateChange();

            return { success: true, user };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    // Выход пользователя
    logout() {
        this.currentUser = null;
        this.isAuthenticated = false;
        localStorage.removeItem('user');
        this.notifyAuthStateChange();
    }

    // Валидация данных пользователя
    validateUserData(userData) {
        if (!userData.email || !userData.email.includes('@')) {
            throw new Error('Некорректный email');
        }
        if (!userData.password || userData.password.length < 6) {
            throw new Error('Пароль должен содержать минимум 6 символов');
        }
        if (!userData.name || userData.name.length < 2) {
            throw new Error('Имя должно содержать минимум 2 символа');
        }
    }

    // Подписка на изменения состояния аутентификации
    onAuthStateChanged(callback) {
        this.authStateListeners.add(callback);
        return () => this.authStateListeners.delete(callback);
    }

    // Уведомление об изменении состояния аутентификации
    notifyAuthStateChange() {
        this.authStateListeners.forEach(callback => 
            callback(this.isAuthenticated, this.currentUser)
        );
    }

    // Хеширование пароля (заглушка)
    async hashPassword(password) {
        // В реальном приложении использовать bcrypt или подобную библиотеку
        return btoa(password);
    }
}

// Класс управления UI аутентификации
class AuthUI {
    constructor(authManager) {
        this.authManager = authManager;
        this.setupEventListeners();
        this.authManager.onAuthStateChanged(this.updateUI.bind(this));
    }

    // Настройка обработчиков событий
    setupEventListeners() {
        document.getElementById('registerForm')?.addEventListener('submit', this.handleRegister.bind(this));
        document.getElementById('loginForm')?.addEventListener('submit', this.handleLogin.bind(this));
        document.getElementById('logoutButton')?.addEventListener('click', this.handleLogout.bind(this));
    }

    // Обработка регистрации
    async handleRegister(event) {
        event.preventDefault();
        const formData = new FormData(event.target);
        
        const result = await this.authManager.register({
            email: formData.get('email'),
            password: formData.get('password'),
            name: formData.get('name')
        });

        if (result.success) {
            this.showMessage('success', 'Регистрация успешна!');
            this.closeAuthModal();
        } else {
            this.showMessage('error', result.error);
        }
    }

    // Обработка входа
    async handleLogin(event) {
        event.preventDefault();
        const formData = new FormData(event.target);
        
        const result = await this.authManager.login({
            email: formData.get('email'),
            password: formData.get('password')
        });

        if (result.success) {
            this.showMessage('success', 'Вход выполнен успешно!');
            this.closeAuthModal();
        } else {
            this.showMessage('error', result.error);
        }
    }

    // Обработка выхода
    handleLogout() {
        this.authManager.logout();
        this.showMessage('info', 'Вы вышли из системы');
    }

    // Обновление UI в зависимости от состояния аутентификации
    updateUI(isAuthenticated, user) {
        const authButtons = document.querySelector('.auth-buttons');
        const userProfile = document.querySelector('.user-profile');
        
        if (isAuthenticated && user) {
            authButtons.style.display = 'none';
            userProfile.style.display = 'flex';
            userProfile.querySelector('.user-name').textContent = user.name;
        } else {
            authButtons.style.display = 'flex';
            userProfile.style.display = 'none';
        }
    }

    // Отображение сообщений пользователю
    showMessage(type, message) {
        const messageElement = document.createElement('div');
        messageElement.className = `message message-${type}`;
        messageElement.textContent = message;
        
        document.body.appendChild(messageElement);
        setTimeout(() => messageElement.remove(), 3000);
    }

    // Закрытие модального окна аутентификации
    closeAuthModal() {
        const modal = document.querySelector('.auth-modal');
        if (modal) {
            modal.style.display = 'none';
        }
    }
}

// Экспорт классов
export { AuthManager, AuthUI }; 