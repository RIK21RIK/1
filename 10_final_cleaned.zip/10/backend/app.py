from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import StreamingResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
import psycopg2
import io

app = FastAPI()

# 🔹 Подключение к БД PostgreSQL
conn = psycopg2.connect(
    dbname="files_db",
    user="user",
    password="password",
    host="db"
)
cursor = conn.cursor()

# 🔹 Подключаем статическую папку
app.mount("/static", StaticFiles(directory="static"), name="static")

# 🔹 Редирект с корня на index.html
@app.get("/")
def root():
    return RedirectResponse(url="/static/index.html")

# 🔹 Загрузка файла
@app.post("/upload/")
async def upload(file: UploadFile = File(...)):
    content = await file.read()
    cursor.execute(
        "INSERT INTO files (filename, content) VALUES (%s, %s)",
        (file.filename, psycopg2.Binary(content))
    )
    conn.commit()
    return {"message": "File uploaded", "filename": file.filename}

# 🔹 Получение списка файлов
@app.get("/files/")
def list_files():
    cursor.execute("SELECT id, filename, uploaded_at FROM files ORDER BY uploaded_at DESC")
    rows = cursor.fetchall()
    return [{"id": row[0], "filename": row[1], "uploaded_at": row[2]} for row in rows]

# 🔹 Скачивание файла
@app.get("/download/{file_id}")
def download(file_id: int):
    cursor.execute("SELECT filename, content FROM files WHERE id = %s", (file_id,))
    result = cursor.fetchone()
    if not result:
        raise HTTPException(status_code=404, detail="File not found")
    filename, content = result
    return StreamingResponse(io.BytesIO(content), media_type="application/octet-stream", headers={
        "Content-Disposition": f"attachment; filename={filename}"
    })

# 🔹 Удаление файла
@app.delete("/delete/{file_id}")
def delete_file(file_id: int):
    cursor.execute("DELETE FROM files WHERE id = %s RETURNING id", (file_id,))
    result = cursor.fetchone()
    if not result:
        raise HTTPException(status_code=404, detail="File not found")
    conn.commit()
    return {"message": f"File with ID {file_id} deleted"}

